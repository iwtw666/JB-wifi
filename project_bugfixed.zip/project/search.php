<?php
$xml=new DOMDocument();
$xml->load("songs.xml");
$link=$xml->getElementsByTagName('link');
$q=$_GET["q"];
if (strlen($q)>0){
    $hint="";
    for($i=0; $i<($link->length); $i++){
        $title=$link->item($i)->getElementsByTagName('title');
        $url=$link->item($i)->getElementsByTagName('url');
        if ($title->item(0)->nodeType==1){
            if (stristr($title->item(0)->childNodes->item(0)->nodeValue,$q)){
                if ($hint==""){
                    $hint="<a href='".$url->item(0)->childNodes->item(0)->nodeValue
                    ."'target='_blank'>".$title->item(0)->childNodes->item(0)->nodeValue."</a>";
                }else{
                    $hint=$hint."<br/><a href='"
                    .$url->item(0)->childNodes->item(0)->nodeValue
                    ."'target='_blank'>".$title->item(0)->childNodes->item(0)->nodeValue."</a>";
                }
            }
        }
    }
}
if ($hint==""){
    $response="no results";
}else{
    $response=$hint;
}
echo $response;
?>