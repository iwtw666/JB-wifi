<?php
$_api = "https://www.data.qld.gov.au/api/3/action/datastore_search?resource_id=1275335e-72c8-4848-ae39-94275defe86d";
$_data = file_get_contents($_api);
$_data = json_decode($_data, true);
if ($_GET["id"]) {$_picNo=$_GET["id"];} else {$_picNo=2;}
?>

<html>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/style.css">
    <title>More Information</title>
    
    <body style="text-align:center; margin-top:5%">
    <div style="position:absolute; left:5%; top:0; font-size:1.2em">
    <a href="index.php">Homepage</a>
</div>
        <?php
    foreach($_data["result"]["records"] as $recordKey =>$recordValue) {
    $recordId = $recordValue["_id"];
    $recordTitle = $recordValue["Title"]; 
    $recordCreator = $recordValue["Creator"];
    $subject=$recordValue["Subjects"];
    $contributor=$recordValue["Contributor"];
    $format=$recordValue["Format"];
    $source=$recordValue["Source"];
    $recordDescription = $recordValue["Description"];
    $recordURL = $recordValue["URL"];
    $realURL =  "https".substr($recordURL,4);
    if ($recordId == $_picNo) {
        echo "<h3>Title: </h3>" . "<p>$recordTitle</p>" . "<br>";
        echo "<h3>Creator: </h3>" . "<p>$recordCreator</p>" ."<br>";
        echo "<h3>Subjects: </h3>" . "<p>$subject</p>" ."<br>";
        echo "<h3>Contributor: </h3>" . "<p>$contributor</p>" ."<br>";
        echo "<h3>Format: </h3>" . "<p>$format</p>" ."<br>";
        echo "<h3>Source: </h3>" . "<p>$source</p>" ."<br>";
        echo "<h3>Description: </h3>" . "<p>$recordDescription</p>" ."<br>";
        echo "<h3>URL: </h3>" . "<a href=$realURL>" . $realURL. "</a>";
    }
}
?>
</body>
</html>