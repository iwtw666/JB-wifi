<?php
    session_start();
    if (isset($_POST["submit"])) {
        if (isset($_POST["remember"])) {
            setcookie("username", $_POST["name"], time() + 3600*8*1, "/");
            setcookie("username", $_POST["name"], time() + 3600*8*1, "/");
            setcookie("password1", $_POST["password"], time() + 3600*8*1, "/");
            $_COOKIE["username"] = $_POST["name"];
            $_COOKIE["username1"] = $_POST["name"];
            $_COOKIE["password1"] = $_POST["password"];
        } else {
            setcookie("username", null, -1, "/");
            setcookie("username1", null, -1, "/");
            setcookie("password1", null, -1, "/");
        }
        // $conn = mysqli_connect('localhost', 'root', '', 'users');
$conn = mysqli_connect('localhost', 'test', '123', 'users');
        $username = $_POST["name"];
        $query = "SELECT * FROM user WHERE username = '$username'";
        $result = mysqli_query($conn,$query);
        $row = mysqli_fetch_array($result);
        $ckpassword=$_POST['password'];
        if ($row) {
            if ($ckpassword==$row['password']) {
                $_SESSION["username"] = $_POST["name"];                
                header("Location: home.php");
                echo($_POST["name"]);
            } else {
                echo "<script> {window.alert('Incorrect Password!');};</script>";
            } 
        } else {
            echo "<script> {window.alert('Username not found!');};</script>";
        }
    }

    if (isset($_GET["logout"])) {
        if(isset($_COOKIE['username'])){ 
            setcookie('username','',time()-1,'/');
        }
        session_destroy();
        header("Location: home.php");
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='UTF-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./css/login.css">
        <title>Login</title>
    </head>
    <body>
    <div id='naviga'>
    <a href="home.php">Homepage</a>
    <a href="login.php" id="signIn">Sign in</a>
    <a href="signup.php" id="signUp">Sign up</a>
</div>
        <div id="loginform">
            <h1>Log in</h1>
            <form action="login.php" method="POST">
                <p><label class='input'>Username</label>
                <input class='field' type="text" name="name" placeholder="please type your username" 
                value="<?php if (isset($_COOKIE["username"])): echo $_COOKIE["username1"]; endif ?>" required></p>
                <p><label class='input'>Password</label>
                <input class='field' type="password" name="password" placeholder="please type your password" value="<?php if (isset($_COOKIE["password1"])): echo $_COOKIE["password1"]; endif ?>" required></p>
                <input  type="checkbox" id="remember" name="remember" style="box-shadow:none;width:18px;"
                <?php if (isset($_COOKIE["username"])): echo "checked"; endif ?>>
                <label for="remember">Remember me</label>
                <button class='btn' type="submit" name="submit"> login</button>
            </form>
        </div>
    </body>
</html>