<?php
if ($_GET["id"]) {$_picNo=$_GET["id"];} else {$_picNo=2;}
$conn = new mysqli('localhost', 'test', '123', 'users');
// $conn = new mysqli('localhost', 'root', '', 'users');
$query="SELECT * FROM song WHERE id = $_picNo;";
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_array($result);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/piano.css">
    <title>Piano</title>
</head>

    <body onselectstart="return false;">
        <header>
            <a href="home.php">Homepage</a>
            &#160&#160&#160|&#160&#160&#160
            <p>Piano</p>
        </header>
        <main>
            <div id="score">
                <?php 
                    echo "
                    <img src=".$row["web1"]." style='position:absolute; left:0;'>
            <img src=".$row["web2"]." style='position:absolute;right:0'>";
               ?>
            </div>
        <footer>
            <div class="pianoKey">
                <div id="button-q" class="white">
                    <p>Q</p>
                </div>
                <div id="button-w" class="black">
                    <p>W</p>
                </div>
                <div id="button-e" class="white">
                    <p>E</p>
                </div>
                <div id="button-r" class="black">
                    <p>R</p>
                </div>
                <div id="button-t" class="white">
                    <p>T</p>
                </div>
                <div id="button-y" class="white">
                    <p>Y</p>
                </div>
                <div id="button-u" class="black">
                    <p>U</p>
                </div>
                <div id="button-i" class="white">
                    <p>I</p>
                </div>
                <div id="button-o" class="black">
                    <p>O</p>
                </div>
                <div id="button-p" class="white">
                    <p>P</p>
                </div>
                <div id="button-a" class="black">
                    <p>A</p>
                </div>
                <div id="button-s" class="white">
                    <p>S</p>
                </div>
                <div id="button-d" class="white">
                    <p>D</p>
                </div>
                <div id="button-f" class="black">
                    <p>F</p>
                </div>
                <div id="button-g" class="white">
                    <p>G</p>
                </div>
                <div id="button-h" class="black">
                    <p>H</p>
                </div>
                <div id="button-j" class="white">
                    <p>J</p>
                </div>
                <div id="button-k" class="white">
                    <p>K</p>
                </div>
                <div id="button-l" class="black">
                    <p>L</p>
                </div>
                <div id="button-z" class="white">
                    <p>Z</p>
                </div>
                <div id="button-x" class="black">
                    <p>X</p>
                </div>
                <div id="button-c" class="white">
                    <p>C</p>
                </div>
                <div id="button-v" class="black">
                    <p>V</p>
                </div>
                <div id="button-b" class="white">
                    <p>B</p>
                </div>
                <div id="button-n" class="white">
                    <p>N</p>
                </div>
                <div id="button-m" class="black">
                    <p>M</p>
                </div>
                <div id="button-27" class="white">
                    <p>,</p>
                </div>
                <div id="button-28" class="black">
                    <p>.</p>
                </div>
                <div id="button-29" class="white">
                    <p>/</p>
                </div>
                <div id="button-30" class="white">
                    <p></p>
                </div>
            </footer>
        </footer>
        </main>
       <audio id="keysound1" src="" autoplay></audio>
       <audio id="keysound2" src="" autoplay></audio>
       <audio id="keysound3" src="" autoplay></audio>
       <audio id="keysound4" src="" autoplay></audio>
       <audio id="keysound5" src="" autoplay></audio>
       <audio id="keysound6" src="" autoplay></audio>
       <audio id="keysound7" src="" autoplay></audio>
       <audio id="keysound8" src="" autoplay></audio>
       <audio id="keysound9" src="" autoplay></audio>
       <audio id="keysound10" src="" autoplay></audio>
       <audio id="keysound11" src="" autoplay></audio>
       <audio id="keysound12" src="" autoplay></audio>
       <audio id="keysound13" src="" autoplay></audio>
       <audio id="keysound14" src="" autoplay></audio>
       <audio id="keysound15" src="" autoplay></audio>
       <audio id="keysound16" src="" autoplay></audio>
       <audio id="keysound17" src="" autoplay></audio>
       <audio id="keysound18" src="" autoplay></audio>
       <audio id="keysound19" src="" autoplay></audio>
       <audio id="keysound20" src="" autoplay></audio>
       <audio id="keysound21" src="" autoplay></audio>
       <audio id="keysound22" src="" autoplay></audio>
       <audio id="keysound23" src="" autoplay></audio>
       <audio id="keysound24" src="" autoplay></audio>
       <audio id="keysound25" src="" autoplay></audio>
       <audio id="keysound26" src="" autoplay></audio>
       <audio id="keysound27" src="" autoplay></audio>
       <audio id="keysound28" src="" autoplay></audio>
       <audio id="keysound29" src="" autoplay></audio>
    </body>
    
    <script>
        var key1=document.getElementById('button-q');
        var key2=document.getElementById('button-w');
        var key3=document.getElementById('button-e');
        var key4=document.getElementById('button-r');
        var key5=document.getElementById('button-t');
        var key6=document.getElementById('button-y');
        var key7=document.getElementById('button-u');
        var key8=document.getElementById('button-i');
        var key9=document.getElementById('button-o');
        var key10=document.getElementById('button-p');
        var key11=document.getElementById('button-a');
        var key12=document.getElementById('button-s');
        var key13=document.getElementById('button-d');
        var key14=document.getElementById('button-f');
        var key15=document.getElementById('button-g');
        var key16=document.getElementById('button-h');
        var key17=document.getElementById('button-j');
        var key18=document.getElementById('button-k');
        var key19=document.getElementById('button-l');
        var key20=document.getElementById('button-z');
        var key21=document.getElementById('button-x');
        var key22=document.getElementById('button-c');
        var key23=document.getElementById('button-v');
        var key24=document.getElementById('button-b');
        var key25=document.getElementById('button-n');
        var key26=document.getElementById('button-m');
        var key27=document.getElementById('button-27');
        var key28=document.getElementById('button-28');
        var key29=document.getElementById('button-29');
        // mouise click
        key1.addEventListener('mousedown',function(){
            key1.style.boxShadow='1px 1px 5px black inset';
            keysound1.src='./sound/1.mp3';
        })
        key1.addEventListener('mouseup',function(){
            key1.style.boxShadow='none';
        })
        
        key2.addEventListener('mousedown',function(){
            key2.style.boxShadow='1px 1px 5px black inset';
            keysound2.src='./sound/2.mp3';
        })
        key2.addEventListener('mouseup',function(){
            key2.style.boxShadow='none';
        })
        
        key3.addEventListener('mousedown',function(){
            key3.style.boxShadow='1px 1px 5px black inset';
            keysound3.src='./sound/3.mp3';
        })
        key3.addEventListener('mouseup',function(){
            key3.style.boxShadow='none';
        })
        
        key4.addEventListener('mousedown',function(){
            key4.style.boxShadow='1px 1px 5px black inset';
            keysound4.src='./sound/4.mp3';
        })
        key4.addEventListener('mouseup',function(){
            key4.style.boxShadow='none';
        })
        
        key5.addEventListener('mousedown',function(){
            key5.style.boxShadow='1px 1px 5px black inset';
            keysound5.src='./sound/5.mp3';
        })
        key5.addEventListener('mouseup',function(){
            key5.style.boxShadow='none';
        })
        
        key6.addEventListener('mousedown',function(){
            key6.style.boxShadow='1px 1px 5px black inset';
            keysound6.src='./sound/6.mp3';
        })
        key6.addEventListener('mouseup',function(){
            key6.style.boxShadow='none';
        })
        
        key7.addEventListener('mousedown',function(){
            key7.style.boxShadow='1px 1px 5px black inset';
            keysound7.src='./sound/7.mp3';
        })
        key7.addEventListener('mouseup',function(){
            key7.style.boxShadow='none';
        })
        
        key8.addEventListener('mousedown',function(){
            key8.style.boxShadow='1px 1px 5px black inset';
            keysound8.src='./sound/8.mp3';
        })
        key8.addEventListener('mouseup',function(){
            key8.style.boxShadow='none';
        })
        
        key9.addEventListener('mousedown',function(){
            key9.style.boxShadow='1px 1px 5px black inset';
            keysound9.src='./sound/9.mp3';
        })
        key9.addEventListener('mouseup',function(){
            key9.style.boxShadow='none';
        })
        
        key10.addEventListener('mousedown',function(){
            key10.style.boxShadow='1px 1px 5px black inset';
            keysound10.src='./sound/10.mp3';
        })
        key10.addEventListener('mouseup',function(){
            key10.style.boxShadow='none';
        })
        
        key11.addEventListener('mousedown',function(){
            key11.style.boxShadow='1px 1px 5px black inset';
            keysound11.src='./sound/11.mp3';
        })
        key11.addEventListener('mouseup',function(){
            key11.style.boxShadow='none';
        })
        
        key12.addEventListener('mousedown',function(){
            key12.style.boxShadow='1px 1px 5px black inset';
            keysound12.src='./sound/12.mp3';
        })
        key12.addEventListener('mouseup',function(){
            key12.style.boxShadow='none';
        })

        key13.addEventListener('mousedown',function(){
            key13.style.boxShadow='1px 1px 5px black inset';
            keysound13.src='./sound/13.mp3';
        })
        key13.addEventListener('mouseup',function(){
            key13.style.boxShadow='none';
        })

        key14.addEventListener('mousedown',function(){
            key14.style.boxShadow='1px 1px 5px black inset';
            keysound14.src='./sound/14.mp3';
        })
        key14.addEventListener('mouseup',function(){
            key14.style.boxShadow='none';
        })

        key15.addEventListener('mousedown',function(){
            key15.style.boxShadow='1px 1px 5px black inset';
            keysound15.src='./sound/15.mp3';
        })
        key15.addEventListener('mouseup',function(){
            key15.style.boxShadow='none';
        })

        key16.addEventListener('mousedown',function(){
            key16.style.boxShadow='1px 1px 5px black inset';
            keysound16.src='./sound/16.mp3';
        })
        key16.addEventListener('mouseup',function(){
            key16.style.boxShadow='none';
        })

        key17.addEventListener('mousedown',function(){
            key17.style.boxShadow='1px 1px 5px black inset';
            keysound17.src='./sound/17.mp3';
        })
        key17.addEventListener('mouseup',function(){
            key17.style.boxShadow='none';
        })

        key18.addEventListener('mousedown',function(){
            key18.style.boxShadow='1px 1px 5px black inset';
            keysound18.src='./sound/18.mp3';
        })
        key18.addEventListener('mouseup',function(){
            key18.style.boxShadow='none';
        })

        key19.addEventListener('mousedown',function(){
            key19.style.boxShadow='1px 1px 5px black inset';
            keysound19.src='./sound/19.mp3';
        })
        key19.addEventListener('mouseup',function(){
            key19.style.boxShadow='none';
        })

        key20.addEventListener('mousedown',function(){
            key20.style.boxShadow='1px 1px 5px black inset';
            keysound20.src='./sound/20.mp3';
        })
        key20.addEventListener('mouseup',function(){
            key20.style.boxShadow='none';
        })

        key21.addEventListener('mousedown',function(){
            key21.style.boxShadow='1px 1px 5px black inset';
            keysound21.src='./sound/21.mp3';
        })
        key21.addEventListener('mouseup',function(){
            key21.style.boxShadow='none';
        })

        key22.addEventListener('mousedown',function(){
            key22.style.boxShadow='1px 1px 5px black inset';
            keysound22.src='./sound/22.mp3';
        })
        key22.addEventListener('mouseup',function(){
            key22.style.boxShadow='none';
        })

        key23.addEventListener('mousedown',function(){
            key23.style.boxShadow='1px 1px 5px black inset';
            keysound23.src='./sound/23.mp3';
        })
        key23.addEventListener('mouseup',function(){
            key23.style.boxShadow='none';
        })

        key24.addEventListener('mousedown',function(){
            key24.style.boxShadow='1px 1px 5px black inset';
            keysound24.src='./sound/24.mp3';
        })
        key24.addEventListener('mouseup',function(){
            key24.style.boxShadow='none';
        })

        key25.addEventListener('mousedown',function(){
            key25.style.boxShadow='1px 1px 5px black inset';
            keysound25.src='./sound/25.mp3';
        })
        key25.addEventListener('mouseup',function(){
            key25.style.boxShadow='none';
        })

        key26.addEventListener('mousedown',function(){
            key26.style.boxShadow='1px 1px 5px black inset';
            keysound26.src='./sound/26.mp3';
        })
        key26.addEventListener('mouseup',function(){
            key26.style.boxShadow='none';
        })

        key27.addEventListener('mousedown',function(){
            key27.style.boxShadow='1px 1px 5px black inset';
            keysound27.src='./sound/27.mp3';
        })
        key27.addEventListener('mouseup',function(){
            key27.style.boxShadow='none';
        })

        key28.addEventListener('mousedown',function(){
            key28.style.boxShadow='1px 1px 5px black inset';
            keysound28.src='./sound/28.mp3';
        })
        key28.addEventListener('mouseup',function(){
            key28.style.boxShadow='none';
        })

        key29.addEventListener('mousedown',function(){
            key29.style.boxShadow='1px 1px 5px black inset';
            keysound29.src='./sound/29.mp3';
        })
        key29.addEventListener('mouseup',function(){
            key29.style.boxShadow='none';
        })
        
        
        // keyboard key up down
        window.onkeydown=function(e){
            if(e.key=='q' || e.key=='Q'){
               key1.style.boxShadow='1px 1px 5px black inset';
               keysound1.src='./sound/1.mp3';
        } 
            if(e.key=='w' || e.key=='W'){
               key2.style.boxShadow='1px 1px 5px white inset';
               keysound2.src='./sound/2.mp3';
        } 
            if(e.key=='e' || e.key=='E'){
               key3.style.boxShadow='1px 1px 5px black inset';
               keysound3.src='./sound/3.mp3';
        } 
            if(e.key=='r' || e.key=='R'){
               key4.style.boxShadow='1px 1px 5px white inset';
               keysound4.src='./sound/4.mp3';
        } 
            if(e.key=='t' || e.key=='T'){
               key5.style.boxShadow='1px 1px 5px black inset';
               keysound5.src='./sound/5.mp3';
        } 
            if(e.key=='y' || e.key=='Y'){
               key6.style.boxShadow='1px 1px 5px black inset';
               keysound6.src='./sound/6.mp3';
        } 
            if(e.key=='u' || e.key=='U'){
               key7.style.boxShadow='1px 1px 5px white inset';
               keysound7.src='./sound/7.mp3';
        } 
            if(e.key=='i' || e.key=='I'){
               key8.style.boxShadow='1px 1px 5px black inset';
               keysound8.src='./sound/8.mp3';
        } 
            if(e.key=='o' || e.key=='O'){
               key9.style.boxShadow='1px 1px 5px white inset';
               keysound9.src='./sound/9.mp3';
        } 
            if(e.key=='p' || e.key=='P'){
               key10.style.boxShadow='1px 1px 5px black inset';
               keysound10.src='./sound/10.mp3';
        } 
            if(e.key=='a' || e.key=='A'){
               key11.style.boxShadow='1px 1px 5px white inset';
               keysound11.src='./sound/11.mp3';
        } 
            if(e.key=='s' || e.key=='S'){
               key12.style.boxShadow='1px 1px 5px black inset';
               keysound12.src='./sound/12.mp3';
        } 
          
            if(e.key=='d' || e.key=='D'){
               key13.style.boxShadow='1px 1px 5px black inset';
               keysound13.src='./sound/13.mp3';
        } 
   
            if(e.key=='f' || e.key=='F'){
               key14.style.boxShadow='1px 1px 5px white inset';
               keysound14.src='./sound/14.mp3';
        } 
            if(e.key=='g' || e.key=='G'){
               key15.style.boxShadow='1px 1px 5px black inset';
               keysound15.src='./sound/15.mp3';
        } 
   
            if(e.key=='h' || e.key=='H'){
               key16.style.boxShadow='1px 1px 5px white inset';
               keysound16.src='./sound/16.mp3';
        } 
        
            if(e.key=='j' || e.key=='J'){
               key17.style.boxShadow='1px 1px 5px black inset';
               keysound17.src='./sound/17.mp3';
        } 
        
            if(e.key=='k' || e.key=='K'){
               key18.style.boxShadow='1px 1px 5px black inset';
               keysound18.src='./sound/18.mp3';
        } 
        
            if(e.key=='l' || e.key=='L'){
               key19.style.boxShadow='1px 1px 5px white inset';
               keysound19.src='./sound/19.mp3';
        } 
        
            if(e.key=='z' || e.key=='Z'){
               key20.style.boxShadow='1px 1px 5px black inset';
               keysound20.src='./sound/20.mp3';
        } 
            if(e.key=='x' || e.key=='X'){
               key21.style.boxShadow='1px 1px 5px white inset';
               keysound21.src='./sound/21.mp3';
        } 
            if(e.key=='c' || e.key=='C'){
               key22.style.boxShadow='1px 1px 5px black inset';
               keysound22.src='./sound/22.mp3';
        } 
            if(e.key=='v' || e.key=='V'){
               key23.style.boxShadow='1px 1px 5px white inset';
               keysound23.src='./sound/23.mp3';
        } 
        
            if(e.key=='b' || e.key=='B'){
               key24.style.boxShadow='1px 1px 5px black inset';
               keysound24.src='./sound/24.mp3';
        } 
            if(e.key=='n' || e.key=='N'){
               key25.style.boxShadow='1px 1px 5px black inset';
               keysound25.src='./sound/25.mp3';
        } 
            if(e.key=='m' || e.key=='M'){
               key26.style.boxShadow='1px 1px 5px white inset';
               keysound26.src='./sound/26.mp3';
        } 
            if(e.key==','){
               key27.style.boxShadow='1px 1px 5px black inset';
               keysound27.src='./sound/27.mp3';
        } 
            if(e.key=='.'){
               key28.style.boxShadow='1px 1px 5px white inset';
               keysound28.src='./sound/28.mp3';
        } 
            if(e.key=='/'){
               key29.style.boxShadow='1px 1px 5px black inset';
               keysound29.src='./sound/29.mp3';
        } 
    }
    window.onkeyup=function(e){
        if(e.key=='q' || e.key=='Q'){
            key1.style.boxShadow='none';
            }

        if(e.key=='w' || e.key=='W'){
        
            key2.style.boxShadow='none';
            }
            
        if(e.key=='e' || e.key=='E'){
         
            key3.style.boxShadow='none';
            } 
        
   
        if(e.key=='r' || e.key=='R'){
         
            key4.style.boxShadow='none';
            }
        
        if(e.key=='t' || e.key=='T'){
        
            key5.style.boxShadow='none';
            }
   
        if(e.key=='y' || e.key=='Y'){
    
            key6.style.boxShadow='none';
            }
        
        if(e.key=='u' || e.key=='U'){
  
            key7.style.boxShadow='none';
            }
        
        if(e.key=='i' || e.key=='I'){
  
            key8.style.boxShadow='none';
            }
        
        if(e.key=='o' || e.key=='O'){
  
            key9.style.boxShadow='none';
            }
        
        if(e.key=='p' || e.key=='P'){
  
            key10.style.boxShadow='none';
            }
        
        if(e.key=='a' || e.key=='A'){

            key11.style.boxShadow='none';
            }
        
        if(e.key=='s' || e.key=='S'){
    
            key12.style.boxShadow='none';
            } 

        if(e.key=='d' || e.key=='D'){
         
            key13.style.boxShadow='none';
            } 
   
        if(e.key=='f' || e.key=='F'){
         
            key14.style.boxShadow='none';
            }
        
        if(e.key=='g' || e.key=='G'){
        
            key15.style.boxShadow='none';
            }
   
        if(e.key=='h' || e.key=='H'){
    
            key16.style.boxShadow='none';
            }
        
        if(e.key=='j' || e.key=='J'){
  
            key17.style.boxShadow='none';
            }
        
        if(e.key=='k' || e.key=='K'){
  
            key18.style.boxShadow='none';
            }
        
        if(e.key=='l' || e.key=='L'){
  
            key19.style.boxShadow='none';
            }
        
        if(e.key=='z' || e.key=='Z'){
  
            key20.style.boxShadow='none';
            }
        
        if(e.key=='x' || e.key=='X'){

            key21.style.boxShadow='none';
            }
        
        if(e.key=='c' || e.key=='C'){
    
            key22.style.boxShadow='none';
            } 

        if(e.key=='v' || e.key=='V'){
         
            key23.style.boxShadow='none';
            } 
   
        if(e.key=='b' || e.key=='B'){
         
            key24.style.boxShadow='none';
            }
        
        if(e.key=='n' || e.key=='N'){
        
            key25.style.boxShadow='none';
            }

        if(e.key=='m' || e.key=='M'){
        
            key26.style.boxShadow='none';
            }
        
        if(e.key==','){
         
            key27.style.boxShadow='none';
            }
        
        if(e.key=='.'){
        
            key28.style.boxShadow='none';
            }

        if(e.key=='/'){
        
            key29.style.boxShadow='none';
            }
    }
    document.oncontextmenu=function() {
        return false;
    }
    </script>
</html>