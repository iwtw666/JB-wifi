<?php
    session_start();
    if(empty($_SESSION['username'])){
        if(empty($_COOKIE['username'])){
        }
        else{
            $user=$_COOKIE['username'];
            if(empty($user)){      
            }
            else{ 
                $_SESSION['username']=$user;
            } 
        } 
    } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/style.css">
    <title>Homepage</title>
</head>
<body id="all" onselectstart="return false;">
    <div id="searchcover"></div>
    <header>
        <script>
            function showResult(str){
                if (str.length==0){ 
                    document.getElementById("livesearch").innerHTML="";
                    document.getElementById("livesearch").style.border="0";
                    //document.getElementById("all").setAttribute("class","");
                    document.getElementById("searchcover").setAttribute("class", "")
                    return;
                }
                if (window.XMLHttpRequest){
                    xmlhttp=new XMLHttpRequest();
                } else {
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    if (xmlhttp.readyState==4 && xmlhttp.status==200){
                        document.getElementById("livesearch").innerHTML=xmlhttp.responseText;
                        document.getElementById("livesearch").style.border="1px solid rbg(0,0,0)";
                    }
                }
                xmlhttp.open("GET","search.php?q="+str,true);
                xmlhttp.send();
                //document.getElementById("all").setAttribute("class","ssearch");
                document.getElementById("searchcover").setAttribute("class", "covered")
            }
        </script>
        <div id="logo">
            <img src="./img/logo.jpg" alt="logo">
        </div>
        <div id="searchBar">
            <img src="./img/search.png" alt="">
            <input type = "text" placeholder="I'm looking for..." onkeyup="showResult(this.value)">
            <div id="livesearch" ></div>
        </div>

        <div id="sign">
        <?php if (isset($_SESSION["username"])) {
        echo '<div id="signIn"><a id="user1" onclick="showmenu()" href=# id="signIn">Hi, '.$_SESSION['username']." ".
        '<img src="./img/trangle.png" style="width:10px;"></a>&#160&#160|&#160&#160<a href="signup.php" id="signUp">Sign up</a>
        <div id="menu">
        <a href="login.php?logout">logout</a><br>
        <a href="login.php">switch user</a>
        </div></div>';}
        else {
        echo '<a href="login.php" id="signIn">Sign in</a>&#160&#160|&#160&#160<a href="signup.php" id="signUp">Sign up</a>';}
        ?>
        
        </div>
    </header>

    <main>
        <aside class="album">
            <div>
                <img id="cover1" src="./img/1.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>Brothers in Arms Patriotic Song</p>
                    <p>Herbert, R. Molyneux.</p>
                    <p>★ ★ ★ ☆ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div class="current">
                <img id="cover2" src="./img/2.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>Soldiers of the Willow</p>
                    <p>Zelman, Alerto</p>
                    <p>★ ★ ★ ★ ★</p>        
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover3" src="./img/3.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>The Day of Victory Song</p>
                    <p>Gollmick, Ernest</p>
                    <p>★ ★ ★ ★ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover4" src="./img/4.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>Boys of Australia</p>
                    <p>Caves.J.T.(John Thomas).</p>
                    <p>★ ★ ★ ★ ☆</p>           
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover5" src="./img/5.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>Hear Our Soldiers'cry</p>
                    <p>Harrison, Lorna Maud</p>
                    <p>★ ★ ★ ☆ ☆</p>            
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover6" src="./img/6.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>Joy bells are ringing</p>
                    <p>Miller, Helena</p>
                    <p>★ ★ ★ ☆ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover7" src="./img/7.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>The Kennedy regiment waltz</p>
                    <p>Affoo, Fred A</p>
                    <p>★ ★ ★ ★ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover8" src="./img/8.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>Our boys at the front military song</p>
                    <p>Egan-Mulry, M.</p>
                    <p>★ ★ ★ ☆ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover9" src="./img/9.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>The song of the 42nd Battalion, A.I.F.</p>
                    <p>Hawkins, Henry</p>
                    <p>★ ★ ★ ★ ★</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover10" src="./img/10.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>Black watch junr.</p>
                    <p>Hawkins, Henry</p>
                    <p>★ ★ ★ ☆ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover11" src="./img/11.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>When I march home</p>
                    <p>Rooke, Mark</p>
                    <p>★ ★ ★ ★ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
            <div>
                <img id="cover12" src="./img/12.jpg" ondrag="" ondragstart="drag(event)">
                <div>
                    <p>The liberty song of Australia</p>
                    <p>Teeby.</p>
                    <p>★ ★ ★ ★ ☆</p>
                </div>
                <img src="./img/album.png" alt="">
            </div>
        </aside>

        <section class="player">
                <div id="music">
                    <div>
                        <div ondrop="drop(event)" ondragover="allowDrop(event)">
                            <div id="rotatedRecord">
                                <img src="./img/2.jpg" id="musicCover">
                                <img src="./img/record.png" id="recordShell">
                            </div>
                            <img src="./img/sensor.png" id="sensor">
                        </div>
                        <audio src="./mp3/2.mp3" controls id="audio"></audio>
                        <div class="btn">
                            <button id="favorite"><img src="img/fav1.png"></button>
                            <button id="fav2"><img src="img/fav2.png"></button>
                            <button id="prev"><img src="img/previous.png"></button>
                            <button id="play"><img id="playImg" src="img/play.png"></button>
                            <button id="pause"><img id="pauseImg" src="img/pause.png"></button>
                            <button id="next"><img src="img/next.png"></button>
                            <a id="piano" href="piano.php?id=2"><img src="img/piano.png"></a>
                        </div>
                        <div class="progress">
                            <span class="start"></span>
                            <div class="progress_bar">
                                <div class="now"></div>
                            </div>
                            <span class="end"></span>
                        </div>
                    </div>
                </div>
        </section>
        <aside class="lyric">
            <div id="lyrics">
                <img id="songlyr" src="" alt="This song has no lyrics,
                you can go to piano playing page to try to play it by yourself" style="width:90%">
            </div>
            <div id="bkstory">
                <h3 id="bkname">Background: Soldiers of the Willow</h3>
                <iframe id="bkweb" width="100%" height="520" src="https://www.youtube.com/embed/6NhCdLE3eTg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <a id="learnmore" href="detail.php?id=2">LEARN MORE</a>     
            </div>
            <div id="switch_button">
                <button id="bks">Background Story</button>
                <button id="lyr">Lyric</button>
            </div>
        </aside>     
    </main>
</body>

<script>

    function showmenu() {
        if(menu.style.display=="none"){
            menu.style.display="block";
        }else{
            menu.style.display="none";
        }    
    }
    // play
    play.onclick = function(){
        if(audio.paused){
            audio.play();
            pause.style.display = "initial";
            pauseImg.style.display = "initial";
            play.style.display = "none";
            playImg.style.display = "none";
        }
    }
    
    // pause
    pause.onclick = function(){
        if(audio.played){
            audio.pause();
            playImg.style.display = "initial";
            play.style.display = "initial";
            pauseImg.style.display = "none";
            pause.style.display = "none";
            document.getElementById("sensor").setAttribute("class", "");
            document.getElementById("rotatedRecord").setAttribute("class", "");
        }
    }
    
    var picNo = 1;
    var num=2;
    var len=12; // the number of musics;
    var bgImage = document.getElementById("musicCover");
    
    //prev
    prev.onclick = function(){
        if(num>1){
            num = num - 1;
        }
        else{
            num=len;
        }
        picNo=num;
        audio.src = './mp3/' + num + '.mp3';
        bgImage.style.backgroundImage = 'url(./img/' + num + '.jpg)';
        musicCover.src = './img/' + num + '.jpg';
        audio.play();
        pause.style.display = "initial";
        pauseImg.style.display = "initial";
        play.style.display = "none";
        playImg.style.display = "none";
        document.getElementsByClassName("current")[0].setAttribute("class", "");
        document.getElementById("cover" + num).parentElement.setAttribute("class", "current"); 
        document.getElementById("piano").setAttribute("href","piano.php?id="+ num);   
        document.getElementById("learnmore").setAttribute("href","detail.php?id="+ num);
        // set bkground & lyrics
        if(num==1){
            document.getElementById("bkname").innerHTML="Background: Brothers in Arms Patriotic Song"; 
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/VBFC2cT.jpg");   
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/oXDlLliPFjY");
        }else if(num==2){
            document.getElementById("bkname").innerHTML="Background: Soldiers of the Willow";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/6NhCdLE3eTg");   
        }else if(num==3){
            document.getElementById("bkname").innerHTML="Background: The Day of Victory Song";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/YAmC5Q9.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/_udGcKMhbtc");   
        }else if(num==4){
            document.getElementById("bkname").innerHTML="Background: Boys of Australia";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/PI2HmOuzOBk");   
        }else if(num==5){
            document.getElementById("bkname").innerHTML="Background: Hear Our Soldiers'cry";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/44eubJD.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/rL8u00l0CnE");   
        }else if(num==6){
            document.getElementById("bkname").innerHTML="Background: Joy bells are ringing";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/XWopls1.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/6KHoVBK2EVE");   
        }else if(num==7){
            document.getElementById("bkname").innerHTML="Background: The Kennedy regiment waltz";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/WWqmQlSScI0");   
        }else if(num==8){
            document.getElementById("bkname").innerHTML="Background: Our boys at the front military song";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/qW8O_sisf4I");   
        }else if(num==9){
            document.getElementById("bkname").innerHTML="Background: The 42nd Battalion, A.I.F.";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/ABRZaqT0E0Y");   
        }else if(num==10){
            document.getElementById("bkname").innerHTML="Background: Black watch junr.";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/vY7nQD-FwH4");   
        }else if(num==11){
            document.getElementById("bkname").innerHTML="Background: When I march home";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/qMowBTmHBng");   
        }else if(num==12){
            document.getElementById("bkname").innerHTML="Background: The liberty song of Australia";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/RkUYKKr.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/M1eGBX7t3ZU");   
        }
    }

    // next
    next.onclick = function(){
        if(num<len){
            num = num + 1;
        }
        else{
            num=1;
        }
        picNo=num;
        audio.src = './mp3/' + num + '.mp3';
        bgImage.style.backgroundImage = 'url(./img/' + num + '.jpg)';
        musicCover.src = './img/' + num+ '.jpg';
        audio.play();
        pause.style.display = "initial";
        pauseImg.style.display = "initial";
        play.style.display = "none";
        playImg.style.display = "none";
        document.getElementsByClassName("current")[0].setAttribute("class", "");
        document.getElementById("cover" + num).parentElement.setAttribute("class", "current");  
        document.getElementById("piano").setAttribute("href","piano.php?id="+ num);
        document.getElementById("learnmore").setAttribute("href","detail.php?id="+ num);
         // set bkground & lyrics
         if(num==1){
            document.getElementById("bkname").innerHTML="Background: Brothers in Arms Patriotic Song"; 
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/VBFC2cT.jpg");   
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/oXDlLliPFjY");
        }else if(num==2){
            document.getElementById("bkname").innerHTML="Background: Soldiers of the Willow";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/6NhCdLE3eTg");   
        }else if(num==3){
            document.getElementById("bkname").innerHTML="Background: The Day of Victory Song";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/YAmC5Q9.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/_udGcKMhbtc");   
        }else if(num==4){
            document.getElementById("bkname").innerHTML="Background: Boys of Australia";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/PI2HmOuzOBk");   
        }else if(num==5){
            document.getElementById("bkname").innerHTML="Background: Hear Our Soldiers'cry";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/44eubJD.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/rL8u00l0CnE");   
        }else if(num==6){
            document.getElementById("bkname").innerHTML="Background: Joy bells are ringing";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/XWopls1.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/6KHoVBK2EVE");   
        }else if(num==7){
            document.getElementById("bkname").innerHTML="Background: The Kennedy regiment waltz";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/WWqmQlSScI0");   
        }else if(num==8){
            document.getElementById("bkname").innerHTML="Background: Our boys at the front military song";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/qW8O_sisf4I");   
        }else if(num==9){
            document.getElementById("bkname").innerHTML="Background: The 42nd Battalion, A.I.F.";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/ABRZaqT0E0Y");   
        }else if(num==10){
            document.getElementById("bkname").innerHTML="Background: Black watch junr.";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/vY7nQD-FwH4");   
        }else if(num==11){
            document.getElementById("bkname").innerHTML="Background: When I march home";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/qMowBTmHBng");   
        }else if(num==12){
            document.getElementById("bkname").innerHTML="Background: The liberty song of Australia";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/RkUYKKr.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/M1eGBX7t3ZU");   
        }
    }

    // auto next music
    audio.addEventListener('ended',function(){
        next.onclick();
    },false);

    audio.addEventListener("playing", function(){
        document.getElementById("sensor").setAttribute("class", "working");
        document.getElementById("rotatedRecord").setAttribute("class", "working");
    },false);
    
    // rewrite the playbar
    var start = document.querySelector('.start')
    var end = document.querySelector('.end')
    var progressBar = document.querySelector('.progress_bar')
    var now = document.querySelector('.now')
    
    function conversion (value) {
        let minute = Math.floor(value / 60)
        minute = minute.toString().length === 1 ? ('0' + minute) : minute
        let second = Math.round(value % 60)
        second = second.toString().length === 1 ? ('0' + second) : second
        return `${minute}:${second}`
    }
    
    audio.onloadedmetadata = function () {
        end.innerHTML = conversion(audio.duration)
        start.innerHTML = conversion(audio.currentTime)
    }
    
    progressBar.addEventListener('click', function (event) {
        let coordStart = this.getBoundingClientRect().left
        let coordEnd = event.pageX
        let p = (coordEnd - coordStart) / this.offsetWidth
        now.style.width = p.toFixed(3) * 100 + '%'
    
        audio.currentTime = p * audio.duration
        audio.play()
    })
    
    setInterval(() => {
        start.innerHTML = conversion(audio.currentTime)
        now.style.width = audio.currentTime / audio.duration.toFixed(3) * 100 + '%'
    }, 1000);
    
        // drag 
    function allowDrop(ev){
        ev.preventDefault();
    }
    
    function drag(ev){
        for (var j = 1; j <= 12; j++) {
            if (ev.target.id == "cover" + j) {
                picNo = j;
            }
        }
        ev.dataTransfer.setData("text", ev.target.id);
    }
    
    function drop(ev){
        ev.preventDefault();
        var data = ev.dataTransfer.getData("text");
        if (data == "cover" + picNo) {
            audio.src = './mp3/' + picNo + '.mp3';
            bgImage.style.backgroundImage = 'url(./img/' + picNo + '.jpg)';
            musicCover.src = './img/' + picNo + '.jpg';
            audio.play();
            pause.style.display = "initial";
            pauseImg.style.display = "initial";
            play.style.display = "none";
            playImg.style.display = "none";  
            document.getElementsByClassName("current")[0].setAttribute("class", "");
            for (var i = 1; i <=12; i++) {
                if (picNo == i) {
                    document.getElementById("cover" + i).parentElement.setAttribute("class", "current");
                }
            }
            num=picNo;
            document.getElementById("piano").setAttribute("href","piano.php?id="+ picNo);
            document.getElementById("learnmore").setAttribute("href","detail.php?id="+ picNo);
        // set bkground & lyrics
        if(picNo==1){
            document.getElementById("bkname").innerHTML="Background: Brothers in Arms Patriotic Song"; 
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/VBFC2cT.jpg");   
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/oXDlLliPFjY");
        }else if(picNo==2){
            document.getElementById("bkname").innerHTML="Background: Soldiers of the Willow";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/6NhCdLE3eTg");   
        }else if(picNo==3){
            document.getElementById("bkname").innerHTML="Background: The Day of Victory Song";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/YAmC5Q9.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/_udGcKMhbtc");   
        }else if(picNo==4){
            document.getElementById("bkname").innerHTML="Background: Boys of Australia";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/PI2HmOuzOBk");   
        }else if(picNo==5){
            document.getElementById("bkname").innerHTML="Background: Hear Our Soldiers'cry";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/44eubJD.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/rL8u00l0CnE");   
        }else if(picNo==6){
            document.getElementById("bkname").innerHTML="Background: Joy bells are ringing";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/XWopls1.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/6KHoVBK2EVE");   
        }else if(picNo==7){
            document.getElementById("bkname").innerHTML="Background: The Kennedy regiment waltz";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/WWqmQlSScI0");   
        }else if(picNo==8){
            document.getElementById("bkname").innerHTML="Background: Our boys at the front military song";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/qW8O_sisf4I");   
        }else if(picNo==9){
            document.getElementById("bkname").innerHTML="Background: The 42nd Battalion, A.I.F.";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/ABRZaqT0E0Y");   
        }else if(picNo==10){
            document.getElementById("bkname").innerHTML="Background: Black watch junr.";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/vY7nQD-FwH4");   
        }else if(picNo==11){
            document.getElementById("bkname").innerHTML="Background: When I march home";
            document.getElementById("songlyr").setAttribute("src","");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/qMowBTmHBng");   
        }else if(picNo==12){
            document.getElementById("bkname").innerHTML="Background: The liberty song of Australia";
            document.getElementById("songlyr").setAttribute("src","https://i.imgur.com/RkUYKKr.jpg");
            document.getElementById("bkweb").setAttribute("src","https://www.youtube.com/embed/M1eGBX7t3ZU");   
        }
        }
    }
    // switch between lyric and story
    bks.onclick=function(){
        lyrics.style.display="none";
        bkstory.style.display="initial";
        bks.style.background= "gold";
        lyr.style.background="none";
    }

    lyr.onclick=function(){
        bkstory.style.display="none";
        lyrics.style.display="initial";
        bks.style.background= "none";
        lyr.style.background="gold";
    }
    // favoeite
    favorite.onclick=function(){
        favorite.style.display="none";
        fav2.style.display="initial";
    }
    fav2.onclick=function(){
        favorite.style.display="initial";
        fav2.style.display="none";
    }
    // disable right click
    document.oncontextmenu=function() {
        return false;
    }
    function reurl(){
        url = location.href;
        var times = url.split("?");
        if(times[1] != 1){ 
            url += "?1"; 
            self.location.replace(url);
        }
    }
    onload=reurl
    
</script>
</html>