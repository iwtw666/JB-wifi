<?php 
session_start();

// $conn = mysqli_connect('localhost', 'root', '', 'users');
$conn = mysqli_connect('localhost', 'test', '123', 'users');

if (!$conn) {
    die('Could not connect: ' . mysql_error());
}else {
    if (isset($_POST['submit'])){
        $name=$_POST['name'];
        $pasword=$_POST['password'];
        $ckquery="SELECT username FROM user WHERE username = '$name'";
        $ckus = mysqli_query($conn,$ckquery);
        $hash=password_hash($_POST['password'], PASSWORD_DEFAULT);
        if($ckquery->num_rows != 0){
            exit('Username already exists!<a href="javascript:history.back(-1);"><br>Back</a>');
        }
        else{
            if ($_POST['password'] == $_POST['repw']){
                $query = "INSERT INTO user (username,password) VALUES('$name','$pasword')";
                $result=mysqli_query($conn, $query);
                        echo "<script>alert('Signup Complete!');
                        window.location.href = 'login.php';</script>";}
            else {
                exit('Two passwords are not match!<a href="javascript:history.back(-1);"><br>Back</a>');                }
        }
    }
}        
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='UTF-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Signup</title>
        <link rel="stylesheet" href="./css/login.css">
    </head>
    <body>
    <div id='naviga'>
    <a href="home.php">Homepage</a>
    <a href="login.php" id="signIn">Sign in</a>
    <a href="signup.php" id="signUp">Sign up</a>
</div>
        <div id="signupform">
            <h1>Please Sign up</h1>
            <form action="signup.php" method="POST" >
                <p><label class='input'>Username</label>
                <input class='field' type="text" name="name" placeholder="username" value="" required></p>
                <p><label class='input'>Password</label>
                <input class='field' type="password" name="password" placeholder="password" value="" required></p>
                <p><label class='input'>Confirm</label>
                <input class='field' type="password" name="repw" placeholder="retype password" value="" required></p>
                <button class='btn1'type="submit" name="submit">Sign up and jump to Login </button>
            </form>
        </div>
    </body>
</html>